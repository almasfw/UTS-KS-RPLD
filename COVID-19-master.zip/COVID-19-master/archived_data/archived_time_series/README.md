For the latest updates, please see [csse_covid_19_data](https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data) folder.

# Novel Coronavirus 2019 Time Series Data
The time series data is derived from the daily case reports, and will be updated twice daily.
